﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace TestChartIndonesiaPeople
{
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
                TampilkanGrafik();
            }

            private void TampilkanGrafik()
            {
                // Data jumlah penduduk per provinsi (contoh data)
                string[] provinsi = { "Jawa Barat", "Jawa Timur", "Jawa Tengah", "Sumatera Utara", "Banten", "DKI Jakarta" };
                int[] jumlahPenduduk = { 48846000, 41217000, 36652000, 14826000, 12794000, 10756000 }; // Dalam juta jiwa

                // Set properti Chart
                chart1.Series.Clear();
                chart1.Titles.Add("Jumlah Penduduk Indonesia per Provinsi (2024)");
                chart1.ChartAreas[0].AxisX.Title = "Provinsi";
                chart1.ChartAreas[0].AxisY.Title = "Jumlah Penduduk (Juta Jiwa)";

                // Buat series baru
                Series series = new Series
                {
                    Name = "Penduduk",
                    ChartType = SeriesChartType.Column // Bisa diganti: Pie, Line, Bar, dll.
                };

                // Tambahkan data ke dalam series
                for (int i = 0; i < provinsi.Length; i++)
                {
                    series.Points.AddXY(provinsi[i], jumlahPenduduk[i]);
                }

                // Tambahkan series ke Chart
                chart1.Series.Add(series);
            }

        //private void chart1_Click(object sender, EventArgs e)
        //{

        //}
     }
    }
    //public partial class Form1 : Form
    //{
    //    public Form1()
    //    {
    //        InitializeComponent();
    //    }

    //    private void Form1_Load(object sender, EventArgs e)
    //    {

    //    }
    //}
//}
